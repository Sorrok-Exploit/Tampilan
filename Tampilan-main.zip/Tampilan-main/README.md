# Tampilan
[![Typing SVG](https://readme-typing-svg.herokuapp.com?color=%23FF0000&lines=Mengubah+Tampilan+Termux+Use)](https://git.io/typing-svg)
[![Typing SVG](https://readme-typing-svg.herokuapp.com?color=%23FF0000&lines=This+My+Github+©AmmarBN)](https://git.io/typing-svg)

## Gambar
 <img src="https://github.com/Lord-Ammar/tampilan/blob/main/IMG_20220131_001444.jpg" width="440" title="Menu" alt="Menu">
</p>

## usage
```
pkg update && pkg upgrade
pkg install git && pkg install figlet
pkg install python && pkg install python2
pkg install bash
git clone https://github.com/Lord-Ammar/tampilan
cd tampilan
bash tampilan.sh
Ikutin Yang Ada Di video Tinggal 
Copy Paste Kok Gan😉
```

<a href="https://youtube.com/channel/https://youtube.com/channel/UCFeZ5BGt8lbOZwIj2MNOlIQ" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/youtube.svg" alt="Sanz" height="30" width="40" /></a> Klik Icon YouTube Kalau Belum Paham

### Thanks To 
**Allah SWT**,

**Orang Tua**,

**Semua yang selalu mendukung**

## Developer
[![Lord-Amnar](https://github.com/Lord-Ammar.png?size=100)](https://github.com/Lord-Ammar)
[![AmmarBN](https://github.com/AmmarBN.png?size=100)](https://github.com/AmmarBN)
